﻿# FleetIQ website — Phase 2

Framework-free PHP website with the approved homepage and seven core product pages. Custom CSS and vanilla JavaScript; no build step or application dependencies. Requires PHP 8.1 or newer.

```sh
php -S 127.0.0.1:8080
```

Open http://127.0.0.1:8080. PHP must execute the templates; opening PHP files directly does not render the website.

## Pages

- `index.php`: approved homepage.
- `features.php`: platform overview, ten functional areas and Windows/Web/Android.
- `fleet-vehicles.php`: vehicle records, assignments, documents and dates.
- `drivers-compliance.php`: driver records and operation-specific requirements.
- `workshop.php`: inspection → defect → repair job → completion → history/reporting.
- `documents-reminders.php`: documents, expiry dates, calendar and reminders.
- `reports.php`: recorded vehicle, inspection and workshop activity.
- `mobile.php`: Windows, Web and Android usage.

About and Contact remain homepage sections. Pricing, Login, Customer Stories, Resources, Security and standalone About/Contact pages are not built.

## Shared structure

- `components/header.php`, `navigation.php`, `footer.php`: global shell and navigation.
- `components/demo-cta.php`: shared final CTA.
- `components/icons.php`: SVG icon and FleetIQ brand helpers.
- `components/product-page.php`: reusable product-page layout, capability cards, workflow and related links.
- `components/product-visual.php`: accessible HTML conceptual record/activity and device views.
- `includes/product-pages.json`: page-specific titles, descriptions, copy, visual records and relationships. Keep content within confirmed product scope. All output is escaped by the PHP renderer.
- `includes/config.php`: public origin, demo email and escaping helper.
- `includes/seo.php`: page-aware description, canonical and Open Graph metadata.
- `assets/css/site.css`: approved shared design system; unchanged in Phase 2.
- `assets/css/product.css`: internal-page-only layouts; loaded only on product pages.
- `assets/js/site.js`: mobile menu, native Product disclosure handling and demo/legal dialogs.

Each product entry point selects a fixed content key. Adding a capability to an existing page generally requires only editing its content in the JSON file. Record visuals are semantic HTML with visible conceptual/illustrative captions, not simulated interactive application controls.

## Before deployment

1. Set `SITE_URL` to the confirmed HTTPS site URL in `includes/config.php`. It is currently empty, so canonical and OG URL tags are omitted. Product pages append their own file path; the homepage uses the root.
2. Replace `https://example.invalid` in `sitemap.xml` with the same confirmed origin before publishing/submitting it. All eight routes are listed, but this is a deployment template until configured. Add the absolute sitemap URL to `robots.txt`.
3. Set `DEMO_EMAIL` to a monitored address. Until configured, Book a Demo opens the existing development notice; it does not book an appointment or send an enquiry. Once configured it offers an email enquiry.
4. Supply operator information and approved privacy/terms content. Current legal dialogs are development notices.
5. Review product copy against the shipping application and replace conceptual views when approved screenshots become available.
6. Configure HTTPS and production PHP error handling. Check current Firefox, Safari and real Android devices, including keyboard focus, touch and zoom.

No external fonts, analytics, forms, trackers, frameworks or third-party client scripts are included. Section links and native Product disclosure work without JavaScript. Demo/legal notices are visible fallback sections which JavaScript enhances into dialogs.

## Validation

See `VALIDATION.md`. Phase 2 was linted and rendered with a temporary official PHP 8.4.25 runtime, downloaded outside the repository and verified against the publisher's SHA-256. Chrome checked the actual PHP application at 17 widths across all eight pages. The temporary runtime and QA harnesses are not application dependencies.

```powershell
Get-ChildItem -Recurse -Filter *.php | ForEach-Object { php -l $_.FullName }
```
